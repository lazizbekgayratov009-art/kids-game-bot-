const tg=window.Telegram?.WebApp; if(tg){tg.ready();tg.expand();}
const initData=tg?.initData||"";
const headers={"Content-Type":"application/json","X-Telegram-Init-Data":initData};
const $=id=>document.getElementById(id);
let allGames=[],currentCategory="Barchasi",score=0,best=0,activeGame=null,round=0,correct=0;
const emojis={"🧮 Matematika":"🔢","🧠 Aql charxi":"🧠","🎨 Rang va shakl":"🎨","🐾 Hayvonlar":"🐾","⚔️ Sarguzasht":"🛡️","🧩 Boshqotirma":"🧩","🚀 Chaqqonlik":"🚀","🎯 Xotira va diqqat":"🎯"};
const colors=[["Qizil","🔴"],["Ko‘k","🔵"],["Sariq","🟡"],["Yashil","🟢"]];
async function api(url,opts={}){try{return await fetch(url,{...opts,headers:{...headers,...opts.headers}}).then(r=>r.json())}catch(e){return null}}
async function boot(){allGames=await fetch("/static/games.json").then(r=>r.json());let me=await api("/api/me");if(me){score=me.points;best=me.best;}$("points").textContent=score;$("best").textContent=best;renderCategories();renderGames();}
function renderCategories(){let cats=["Barchasi",...new Set(allGames.map(g=>g.category))];$("categories").innerHTML=cats.map(c=>`<button class="chip ${c===currentCategory?"active":""}" data-cat="${c}">${c}</button>`).join("");$("categories").querySelectorAll("button").forEach(b=>b.onclick=()=>{currentCategory=b.dataset.cat;renderCategories();renderGames()})}
function renderGames(){let list=currentCategory==="Barchasi"?allGames:allGames.filter(g=>g.category===currentCategory);$("listTitle").textContent=currentCategory==="Barchasi"?"Barcha o‘yinlar":currentCategory;$("gameCount").textContent=list.length+" ta o‘yin";$("games").innerHTML=list.map(g=>`<button class="game" data-id="${g.id}"><span class="emoji">${emojis[g.category]||"🎮"}</span><strong>${g.name}</strong><small>${g.category}</small></button>`).join("");$("games").querySelectorAll("button").forEach(b=>b.onclick=()=>startGame(+b.dataset.id))}
function startGame(id){activeGame=allGames.find(g=>g.id===id);round=0;correct=0;$("play").classList.remove("hidden");$("games").parentElement.classList.add("hidden");$("categories").classList.add("hidden");$("gameTitle").textContent=activeGame.name;$("gameIcon").textContent=emojis[activeGame.category]||"🎮";$("feedback").textContent="";nextRound();window.scrollTo(0,0)}
$("back").onclick=()=>{$("play").classList.add("hidden");$("games").parentElement.classList.remove("hidden");$("categories").classList.remove("hidden");renderGames()};
function nextRound(){round++;$("feedback").textContent="";let type=activeGame.type;let stage=$("stage");stage.innerHTML="";
if(round>5){finish();return}
if(type==="math"||type==="compare"||type==="missing"||type==="count"||type==="sequence"){let a=1+Math.floor(Math.random()*9),b=1+Math.floor(Math.random()*9),answer,question;
if(type==="compare"){answer=Math.max(a,b);question=`Qaysi son katta: ${a} yoki ${b}?`}
else if(type==="missing"){answer=a+b;question=`${a} + □ = ${answer}`;answer=b}
else if(type==="sequence"){answer=a+2;question=`Ketma-ketlikni davom ettir: ${a}, ${a+2}, ${a+4}, ?`}
else if(type==="count"){answer=a;question=`🍎 Olmalarni sanang: ${"🍎".repeat(a)}`}
else {answer=a+b;question=`${a} + ${b} = ?`}
quizChoices(question,answer,[answer,answer+1,Math.max(0,answer-1),answer+2]);}
else if(type==="color"){let c=colors[Math.floor(Math.random()*colors.length)];quizChoices(`${c[1]} Bu qaysi rang?`,c[0],colors.map(x=>x[0]));}
else if(type==="shape"){let shapes=[["🔺","Uchburchak"],["🟦","Kvadrat"],["⚪","Doira"],["⭐","Yulduz"]],s=shapes[Math.floor(Math.random()*shapes.length)];quizChoices(`${s[0]} Bu qanday shakl?`,s[1],shapes.map(x=>x[1]));}
else if(type==="battle"){let tasks=[["🤖","Robotga do‘stona signal yubor","📡 Signal"],["🐉","Ajdarhoni tinchlantirish uchun nima beramiz?","🍎 Olma"],["🏰","Qal’ani nimasi bilan himoya qilamiz?","🛡️ Qalqon"],["🚀","Kosmik kemani nima boshqaradi?","🎮 Boshqaruv"],["✨","Sehrli bog‘ni nima bilan asraymiz?","💧 Suv"]];let t=tasks[(round-1)%tasks.length];quizChoices(`${t[0]} ${t[1]}`,t[2],[t[2],"Shovqin","Tosh","Chiqindi"]);}
else if(type==="tap"){stage.innerHTML=`<p>⭐ Yulduzni bosing!</p><button class="tap-target" id="tap">⭐</button>`;$("tap").onclick=()=>answer(true);}
else if(type==="memory"){let seq=["🍎","🐱","🚗","🌟"];let pick=seq[Math.floor(Math.random()*seq.length)];stage.innerHTML=`<p>Esda saqlang: ${pick}</p><div class="answers">${seq.map(x=>`<button class="answer" data-v="${x}">${x}</button>`).join("")}</div>`;setTimeout(()=>{stage.querySelector("p").textContent="Qaysi belgi bor edi?";stage.querySelectorAll("button").forEach(b=>b.onclick=()=>answer(b.dataset.v===pick))},1300);}
else if(type==="odd"){let opts=["🍎","🍎","🍎","🚗"];let shuffled=opts.sort(()=>Math.random()-.5);stage.innerHTML=`<p>Boshqalardan farq qiladiganini toping</p><div class="answers">${shuffled.map((x,i)=>`<button class="answer" data-v="${x}">${x}</button>`).join("")}</div>`;stage.querySelectorAll("button").forEach(b=>b.onclick=()=>answer(b.dataset.v==="🚗"));}
else{quizChoices("Qaysi biri uy hayvoni?","Mushuk",["Mushuk","Sher","Yo‘lbars","Bo‘ri"]);}
}
function quizChoices(q,ans,opts){$("instruction").textContent=q;let uniq=[...new Set(opts)];while(uniq.length<4)uniq.push("—");uniq=uniq.slice(0,4).sort(()=>Math.random()-.5);$("stage").innerHTML=`<div class="answers">${uniq.map(v=>`<button class="answer">${v}</button>`).join("")}</div>`;$("stage").querySelectorAll("button").forEach(b=>b.onclick=()=>answer(String(b.textContent)===String(ans)))}
function answer(ok){if(ok){correct++;score+=10;$("points").textContent=score;$("feedback").textContent="Ajoyib! To‘g‘ri javob! 🌟"}else{$("feedback").textContent="Yaxshi urinish! Keyingisini sinab ko‘r! 💪"}$("stage").querySelectorAll("button").forEach(b=>b.disabled=true);setTimeout(nextRound,850)}
async function finish(){let earned=correct*10;let res=await api("/api/score",{method:"POST",body:JSON.stringify({points:earned})});if(res){score=res.points;best=res.best}$("points").textContent=score;$("best").textContent=best;$("instruction").textContent="O‘yin tugadi!";$("stage").innerHTML=`<div style="font-size:48px">🏆</div><h2>${correct}/5 to‘g‘ri javob</h2><p>+${earned} ball!</p><button class="action" id="again">Yana o‘ynash</button>`;$("again").onclick=()=>{round=0;correct=0;nextRound()};$("feedback").textContent="Sen zo‘rsan! 🎉"}
$("leaders").onclick=async()=>{let rows=await api("/api/leaderboard")||[];$("leaderRows").innerHTML=rows.length?rows.map((r,i)=>`<div class="leader"><span>${i+1}. ${r.username}</span><b>⭐ ${r.points}</b></div>`).join(""):"Hozircha natijalar yo‘q";$("modal").classList.remove("hidden")};
$("closeModal").onclick=()=>$("modal").classList.add("hidden");
boot();
